import { supabase } from "./client";

// =========================
// UTIL DATE
// =========================
function getToday() {
  return new Date().toISOString().split("T")[0];
}

// =========================
// GET STOCK
// =========================
export async function getTodayStock() {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  return data;
}

// =========================
// SAVE TODAY STOCK
// HANYA MEMBUAT DATA BARU
// TIDAK AKAN MEMBUKA TOKO LAGI
// =========================
export async function saveTodayStock(stock: number) {
  const today = getToday();

  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", today)
    .maybeSingle();

  if (error) throw error;

  // Kalau sudah ada data hari ini,
  // jangan diubah lagi.
  if (data) {
    return data;
  }

  const { data: inserted, error: insertError } = await supabase
    .from("daily_stock")
    .insert({
      stock_date: today,
      opening_stock: stock,
      remaining_stock: stock,
      self_consumed: 0,
      is_closed: false,
    })
    .select()
    .maybeSingle();

  if (insertError) throw insertError;

  return inserted;
}

// =========================
// DECREASE STOCK
// UNTUK DONAT YANG TERJUAL
// =========================
export async function decreaseTodayStock(qty: number) {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  if (!data) {
    throw new Error("Stock belum dibuat.");
  }

  const remain = Math.max(
    0,
    Number(data.remaining_stock) - qty
  );

  const { error: updateError } = await supabase
    .from("daily_stock")
    .update({
      remaining_stock: remain,
    })
    .eq("id", data.id);

  if (updateError) throw updateError;
}

// =========================
// RETURN STOCK
// UNTUK VOID TRANSAKSI
// =========================
export async function returnTodayStock(qty: number) {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  if (!data) {
    throw new Error("Stock belum dibuat.");
  }

  const openingStock = Number(data.opening_stock);
  const remainingStock = Number(data.remaining_stock);

  const remain = Math.min(
    openingStock,
    remainingStock + qty
  );

  const { error: updateError } = await supabase
    .from("daily_stock")
    .update({
      remaining_stock: remain,
    })
    .eq("id", data.id);

  if (updateError) throw updateError;
}

// =========================
// SELF CONSUMED
// DONAT DIMAKAN SENDIRI
// =========================
export async function addSelfConsumed(qty: number) {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  if (!data) {
    throw new Error("Stock belum dibuat.");
  }

  const currentRemaining = Number(
    data.remaining_stock
  );

  const consumedQty = Math.min(
    Math.max(0, Number(qty)),
    currentRemaining
  );

  if (consumedQty <= 0) {
    return data;
  }

  const currentSelfConsumed = Number(
    data.self_consumed || 0
  );

  const newRemaining =
    currentRemaining - consumedQty;

  const newSelfConsumed =
    currentSelfConsumed + consumedQty;

  const { data: updated, error: updateError } =
    await supabase
      .from("daily_stock")
      .update({
        remaining_stock: newRemaining,
        self_consumed: newSelfConsumed,
      })
      .eq("id", data.id)
      .select()
      .maybeSingle();

  if (updateError) throw updateError;

  return updated;
}

// =========================
// UPDATE SELF CONSUMED
// SET TOTAL JUMLAH LANGSUNG
// =========================
export async function updateSelfConsumed(
  totalSelfConsumed: number
) {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  if (!data) {
    throw new Error("Stock belum dibuat.");
  }

  const openingStock = Number(data.opening_stock);
  const remainingStock = Number(data.remaining_stock);
  const currentSelfConsumed = Number(
    data.self_consumed || 0
  );

  const soldQty =
    openingStock -
    remainingStock -
    currentSelfConsumed;

  const newSelfConsumed = Math.max(
    0,
    Math.min(
      Number(totalSelfConsumed) || 0,
      openingStock - Math.max(0, soldQty)
    )
  );

  const newRemaining = Math.max(
    0,
    openingStock - soldQty - newSelfConsumed
  );

  const { data: updated, error: updateError } =
    await supabase
      .from("daily_stock")
      .update({
        remaining_stock: newRemaining,
        self_consumed: newSelfConsumed,
      })
      .eq("id", data.id)
      .select()
      .maybeSingle();

  if (updateError) throw updateError;

  return updated;
}

// =========================
// CLOSE DAY
// =========================
export async function closeTodayStock() {
  const { error } = await supabase
    .from("daily_stock")
    .update({
      is_closed: true,
    })
    .eq("stock_date", getToday());

  if (error) throw error;
}

// =========================
// CHECK CLOSED
// =========================
export async function isTodayClosed() {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("is_closed")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  return data?.is_closed ?? false;
}

// =========================
// REFRESH
// =========================
export async function refreshTodayStock() {
  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", getToday())
    .maybeSingle();

  if (error) throw error;

  return data;
}

// =========================
// CREATE OR UPDATE TODAY STOCK
// =========================
export async function saveOrUpdateTodayStock(
  stock: number
) {
  const today = getToday();

  const { data, error } = await supabase
    .from("daily_stock")
    .select("*")
    .eq("stock_date", today)
    .maybeSingle();

  if (error) throw error;

  // BELUM ADA -> INSERT
  if (!data) {
    const { data: inserted, error: insertError } =
      await supabase
        .from("daily_stock")
        .insert({
          stock_date: today,
          opening_stock: stock,
          remaining_stock: stock,
          self_consumed: 0,
          is_closed: false,
        })
        .select()
        .maybeSingle();

    if (insertError) throw insertError;

    return inserted;
  }

  // =========================
  // SUDAH ADA -> UPDATE STOCK
  // =========================

  const openingStock = Number(
    data.opening_stock
  );

  const remainingStock = Number(
    data.remaining_stock
  );

  const selfConsumed = Number(
    data.self_consumed || 0
  );

  // Jumlah yang sudah terjual.
  // Self consumed tidak dihitung sebagai penjualan.
  const currentSales =
    openingStock -
    remainingStock -
    selfConsumed;

  const newRemaining = Math.max(
    0,
    Number(stock) -
      Math.max(0, currentSales) -
      selfConsumed
  );

  const { data: updated, error: updateError } =
    await supabase
      .from("daily_stock")
      .update({
        opening_stock: stock,
        remaining_stock: newRemaining,
      })
      .eq("id", data.id)
      .select()
      .maybeSingle();

  if (updateError) throw updateError;

  return updated;
}